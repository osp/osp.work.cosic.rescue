﻿IPAフォント（IPAゴシック）
― はじめにお読みください ―

IPAフォント(Ver.3)は、JIS X 0213:2004に準拠したTrueTypeベースのOpenTypeフォントです。

IPAフォント(Ver.3)の使用または利用に当たっては、添付の「IPAフォントライセンスv1.0」に定める条件に従ってください。
IPAフォント(Ver.3)を使用し、複製し、または頒布する行為、その他、「IPAフォントライセンスv1.0」に定める権利の利用を行った場合、受領者は「IPAフォントライセンスv1.0」に同意したものと見なします。


IPAフォント（IPAゴシック）   ipag00303.zip
|--はじめにお読みください   Readme_ipag00303.txt
|--IPAフォントライセンスv1.0   IPA_Font_License_Agreement_v1.0.txt
|--IPAゴシック   ipag.ttf


「IPAフォント」は、IPAの登録商標です。

=========================
IPA Font (IPAGothic)
-- Readme --

IPA Fonts are JIS X 0213:2004 compliant TrueType based OpenType format outline fonts.

In using IPA fonts, please comply with the terms and conditions set out in "IPA Font License Agreement v1.0" included in this package.
Any use, reproduction or distribution of the IPA Font or any exercise of rights under "IPA Font License Agreement v1.0" by a Recipient constitutes the Recipient's acceptance of the License Agreement.


IPA Font (IPAGothic)   ipag00303.zip
|--Readme   Readme_ipag00303.txt
|--IPA Font License Agreement v1.0   IPA_Font_License_Agreement_v1.0.txt
|--IPAGothic   ipag.ttf


"IPA Font" is a registered trademark of IPA in Japan.

